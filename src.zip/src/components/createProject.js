import React, { useState } from 'react';
import plus from "../Images/Plus.png"
import { useHistory, useLocation } from "react-router-dom";
import DashboardHeader from './dashboard_header';
import DashboardLeft from './dashboard_left';


const CreateProject = () => {

    const userName = localStorage.getItem("userName");

    const initialValues = {
        project: "",
        phoneNumber: "",
        address: "",
        city: "",
        state:"",
        zipcode: "",
        acreage: "",
        concretesplit: "",
        bulidsplit: "",
        date: "",
        document:"",
        bluePrint:"",
        photo:""
    };
    const location = useLocation();

    const [formValues, setFormValues] = useState(initialValues);
    const [formErrors, setFormErrors] = useState({});

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValues({ ...formValues, [name]: value });
    };

    const history = useHistory();

    const loginButtonClicked = () => {
        let path = "/login";
        history.push(path);
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        setFormErrors(validate(formValues));
        if (
            formValues.project &&
            formValues.phoneNumber &&
            formValues.address &&
            formValues.city &&
            formValues.state &&
            formValues.zipcode && 
            formValues.acreage &&
            formValues.concretesplit &&
            formValues.bulidsplit &&
            formValues.date &&
            formValues.document &&
            formValues.bluePrint &&
            formValues.photo
        ) {
            saveUserData(formValues, location.state.page1, location.state.page2);
            loginButtonClicked();
        }
    };

    const saveUserData = (formValues) => {

        const projectupload = {
            projectName: formValues.project,
            ClientPhNumber: formValues.phoneNumber,
            Address: formValues.address,
            City: formValues.city,
            State: formValues.state,
            Zipcode: formValues.zipcode,
            Acreage: formValues.acreage,
            BuildingSplit: formValues.bulidsplit,
            ConcreteSplit: formValues.concretesplit,
            StartDate: formValues.date,
            Photos: file,
            Blueprints:bluePrint,
            Documents:doc
        };
        console.log("final data", projectupload);
        fetch("http://localhost:3000/save/", {
            method: "POST",
            headers: new Headers({
                Accept: "application/json",
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
            }),
            body: JSON.stringify(projectupload),
        })
            .then((response) => response.json())
            .then((dt) => {
                if (dt) alert("Saved  Successfully");
                else {
                    console.log("......");
                }
            })
            .catch((error) => {
                console.log("error is ", error);
            });
    };

   
   
    const validate = (values) => {
        const error = {};


        if (!values.project) {
            error.project = "Project name is required";
        }
        if (!values.phoneNumber) {
            error.phoneNumber = "phone number is required";
        }
        if (!values.address) {
            error.address = "Address is required";
        }
        if (!values.photo) {
            error.photo = "Please choose an Image";
            document.getElementById("imageUpload").style.display = "block";
        }
        else{
            document.getElementById("imageUpload").style.display = "none";
        }
        if (!values.document) {
            error.document = "Please choose a Document";
            document.getElementById("docUpload").style.display = "block";
        }
        else{
            document.getElementById("docUpload").style.display = "none";
        }
        if (!values.bluePrint) {
            error.bluePrint = "Please choose a Blue Print";
            document.getElementById("fileUpload").style.display = "block";
        }else{
            document.getElementById("fileUpload").style.display = "none";
        }

        if (!values.city && !values.state && values.zipcode) {
            error.threeFiledcity = "Enter the city and state";
        }
        else if (values.city && !values.state && !values.zipcode) {
            error.threeFiledcity = "Enter the state and zipcode";
        }
        else if (!values.city && values.state && !values.zipcode) {
            error.threeFiledcity = "Enter the city and zipcode";
        }
        else if (!values.city && values.state && values.zipcode) {
            error.threeFiledcity = "Enter the city field";
        }
        else if (values.city && !values.state && values.zipcode) {
            error.threeFiledcity = "Enter the state field";
        }
        else if (values.city && values.state && !values.zipcode) {
            error.threeFiledcity = "Enter the zipcode field";
        }
        else if (!values.city && !values.state && !values.zipcode) {
            error.threeFiledcity = "Enter the fields";
        }
        else {
            error.threeFiledcity = "";
        }

        if (!values.acreage && !values.bulidsplit && values.concretesplit) {
            error.threeAcreage = "Enter the acreage and bulidsplit";
        }
        else if (values.acreage && !values.bulidsplit && !values.bulidsplit) {
            error.threeAcreage = "Enter the bulidsplit and concretesplit";
        }
        else if (!values.acreage && values.bulidsplit && !values.concretesplit) {
            error.threeAcreage = "Enter the acreage and concretesplit";
        }
        else if (!values.acreage && values.bulidsplit && values.concretesplit) {
            error.threeAcreage = "Enter the acreage field";
        }
        else if (values.acreage && !values.bulidsplit && values.concretesplit) {
            error.threeAcreage = "Enter the bulidsplit field";
        }
        else if (values.acreage && values.bulidsplit && !values.concretesplit) {
            error.threeAcreage = "Enter the concretesplit field";
        }
        else if (!values.acreage && !values.bulidsplit && !values.concretesplit) {
            error.threeAcreage = "Enter the fields";
        }
        else {
            error.threeAcreage = "";
        }


        if (!values.date) {
            error.date = "Date is required";
        }


        return error;
    };

    const [file, setFile] = useState("");
    const [fileName, setFileName] = useState("Upload Image");
    const [bluePrint, setBluePrint] = useState("");
    const [bluePrintName, setBluePrintName] = useState("Upload Blueprint");
    const [doc, setdoc] = useState("");
    const [docName, setDocName] = useState("Upload Document");
    const handleselectedFile = event => {
        setFile(event.target.files[0]);
        setFileName(event.target.files[0].name);
    };
    const handleselectedBlueFile = event => {
        setBluePrint(event.target.files[0]);
        setBluePrintName(event.target.files[0].name);
    };
    const handleselectedDocFile = event => {
        setdoc(event.target.files[0]);
        setDocName(event.target.files[0].name);
        // selectedDocument: event.target.files[0]
        // selectedDocumentName: event.target.files[0].name
    };
    return (
        <div className='primary_container'>
            <div className='dashboard_page d_flex '>
                <div className='left_side'>
                    <DashboardLeft />
                </div>
                <div className='right_side'>
                    <div className='main_sec d_flex'>
                        <div className='header_con d_flex'>
                            <DashboardHeader userName={userName} />
                        </div>
                        <form className='create_con d_flex' onSubmit={handleSubmit}>
                            <div className='form_sec'>
                                <h1>Project Information.</h1>
                                {/* <form className="form"> */}
                                <div className="login_sec">
                                    <div className="form_container">
                                        <div className="from_field">
                                            <label htmlFor="project" className="label">
                                                Name of Project
                                            </label>
                                            <input
                                                id="project"
                                                className="input_filed"
                                                type="text"
                                                name="project"
                                                value={formValues.project}
                                                onChange={handleChange}
                                            />
                                            <p className="error">{formErrors.project}</p>
                                        </div>
                                        <div className="from_field">
                                            <label htmlFor="phoneNumber" className="label">
                                                Client Phone Number
                                            </label>
                                            <input
                                                id="phoneNumber"
                                                className="input_filed"
                                                type="number"
                                                name="phoneNumber"
                                                value={formValues.phoneNumber}
                                                onChange={handleChange}
                                            />
                                            <p className="error">{formErrors.phoneNumber}</p>
                                        </div>
                                        <div className="from_field">
                                            <label htmlFor="address" className="label">
                                                Address Line 1
                                            </label>
                                            <input
                                                id="address"
                                                className="input_filed"
                                                type="text"
                                                name="address"
                                                value={formValues.address}
                                                onChange={handleChange}
                                            />
                                            <p className="error">{formErrors.address}</p>
                                        </div>
                                        <div className="catogory d_flex">
                                            <div className="from_field">
                                                <label htmlFor="city" className="label">
                                                    City
                                                </label>
                                                <input
                                                    id="city"
                                                    className="input_filed city"
                                                    type="text"
                                                    name="city"
                                                    value={formValues.city}
                                                    onChange={handleChange}
                                                />

                                            </div>
                                            <div className="from_field ">
                                                <label htmlFor="state" className="label">
                                                    State
                                                </label>
                                                <input
                                                    id="state"
                                                    className="input_filed state"
                                                    type="text"
                                                    name="state"
                                                    value={formValues.state}
                                                    onChange={handleChange}
                                                />
                                                {/* <p className="error">{formErrors.comstate}</p> */}
                                            </div>
                                            <div className="from_field">
                                                <label htmlFor="zipcode" className="label">
                                                    Zip Code
                                                </label>
                                                <input
                                                    id="zipcode"
                                                    className="input_filed city"
                                                    type="number"
                                                    name="zipcode"
                                                    value={formValues.zipcode}
                                                    onChange={handleChange}
                                                />
                                                {/* <p className="error">{formErrors.comzipcode}</p> */}
                                            </div>
                                            <p className="error">{formErrors.threeFiledcity}</p>
                                        </div>
                                        <div className="catogory d_flex">
                                            <div className="from_field">
                                                <label htmlFor="acreage" className="label">
                                                    Acreage (ft)
                                                </label>
                                                <input
                                                    id="acreage"
                                                    className="input_filed"
                                                    type="text"
                                                    name="acreage"
                                                    value={formValues.acreage}
                                                    onChange={handleChange}
                                                />

                                            </div>
                                            <div className="from_field ">
                                                <label htmlFor="bulidsplit" className="label">
                                                    Building Split
                                                </label>
                                                <input
                                                    id="bulidsplit"
                                                    className="input_filed"
                                                    type="text"
                                                    name="bulidsplit"
                                                    value={formValues.bulidsplit}
                                                    onChange={handleChange}
                                                />
                                                {/* <p className="error">{formErrors.comstate}</p> */}
                                            </div>
                                            <div className="from_field">
                                                <label htmlFor="concretesplit" className="label">
                                                    Concrete Split
                                                </label>
                                                <input
                                                    id="concretesplit"
                                                    className="input_filed"
                                                    type="text"
                                                    name="concretesplit"
                                                    value={formValues.concretesplit}
                                                    onChange={handleChange}
                                                />
                                                {/* <p className="error">{formErrors.comzipcode}</p> */}
                                            </div>
                                            <p className="error">{formErrors.threeAcreage}</p>
                                        </div>

                                        <div className="catogory d_flex">
                                            <div className="from_field">
                                                <label htmlFor="date" className="label">
                                                    Start Date
                                                </label>
                                                <input
                                                    id="date"
                                                    className="input_filed"
                                                    type="text"
                                                    name="date"
                                                    value={formValues.date}
                                                    onChange={handleChange}
                                                />
                                                <p className="error">{formErrors.date}</p>
                                            </div>
                                        </div>
                                        <div className="from_field">

                                            <input
                                                className="btn"
                                                type="submit"
                                                value="Create Project"

                                            />
                                            {/* <p className="error">{formErrors.companyNumber}</p> */}
                                        </div>
                                    </div>
                                </div>
                                {/* </form> */}
                            </div>
                            <div className='upload_sec d_flex'>
                                <div className='upload_card background_blue d_flex'>
                                    <img src={plus} alt="projectDir" />
                                    <input
                                        class="file-upload-input"
                                        id='file_typeImg'
                                        type='file'
                                        name='photo'
                                        value={formValues.photo}
                                        onChange={handleselectedFile}
                                    />
                                    <label for="file_typeImg">
                                        <span>{fileName}</span>
                                    </label>
                                    <span>Formats accepted HEIC,JPEG,PNG </span>
                                    <span className='tooltip' id='imageUpload'>
                                        {formErrors.photo}
                                    </span>
                                </div>
                                <div className='upload_card background_blue d_flex'>
                                    <img src={plus} alt="projectDir" />
                                    <input
                                        class="file-upload-input"
                                        id="file_typeblueprint"
                                        type='file'
                                        name='bluePrint'
                                        value={formValues.bluePrint}
                                        onChange={handleselectedBlueFile}
                                    />
                                    <label for="file_typeblueprint">
                                        <span>{bluePrintName}</span>
                                    </label>
                                    <span>Formats accepted PDF,Docs</span>
                                    <span className='tooltip' id='fileUpload'>{formErrors.bluePrint}</span>
                                </div>

                                <div className='upload_card background_blue d_flex'>
                                    <img src={plus} alt="projectDir" />
                                    <input
                                        class="file-upload-input"
                                        id='file_typedoc'
                                        type='file'
                                        name='document'
                                        value={formValues.document}
                                        onChange={handleselectedDocFile}
                                    />
                                    <label for="file_typedoc">
                                        <span>{docName}</span>
                                    </label>
                                    <span>Formats accepted PDF, Docs</span>
                                    <span className='tooltip' id='docUpload'>{formErrors.document}</span>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default CreateProject;